



#include<stdio.h>
#include<string.h>
int main()
{
    char k[]="mallow technologies";
    int i,j;
    int len=strlen(k);
    int freq[len];
    for(i=0;i<strlen(k);i++)
    {
        freq[i]=1;
    
    for(j=i+1;j<strlen(k);j++)
    {
        if(k[i]==k[j])
        {
           freq[i]++; 
           k[j]='0';
        }
}
    }


  printf("Characters and their corresponding frequencies\n");  
    for(i = 0; i <len; i++) 
    {  
        if(k[i]!= ' ' && k[i]!= '0')  
            printf("%c-%d\n", k[i], freq[i]);  
    }  
          
    }